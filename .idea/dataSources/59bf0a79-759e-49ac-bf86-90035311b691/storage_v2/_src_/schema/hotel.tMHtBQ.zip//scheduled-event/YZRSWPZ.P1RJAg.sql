create definer = root@localhost event YZRSWPZ on schedule
    at '2021-02-07 00:00:00'
    enable
    do
    DELETE rb
    FROM room_bookings rb
             INNER JOIN user_applications ua ON
            ua.user_id = rb.booked_by_id AND ua.checkin = rb.unavailable_since_date AND
            ua.checkout = rb.unavailable_until_date AND ua.response_room_number = rb.room_id
    WHERE ua.is_paid = 0
      AND ua.id = 34;

